import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import api from './api';

interface User {
  id: number;
  email: string;
  username: string;
  full_name: string | null;
  role: string;
  language: string;
  theme: string;
}

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  updateUser: (user: Partial<User>) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      isAuthenticated: false,

      login: async (email: string, password: string) => {
        const response = await api.post('/auth/login', { email, password });
        const { access_token, user } = response.data;
        
        set({
          user,
          token: access_token,
          isAuthenticated: true,
        });
        
        // Appliquer le thème et la langue
        document.body.classList.toggle('light', user.theme === 'light');
        localStorage.setItem('language', user.language);
      },

      logout: () => {
        set({
          user: null,
          token: null,
          isAuthenticated: false,
        });
      },

      updateUser: (userData: Partial<User>) => {
        const currentUser = get().user;
        if (currentUser) {
          set({ user: { ...currentUser, ...userData } });
        }
      },
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        user: state.user,
        token: state.token,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);

// Store pour le thème
interface ThemeState {
  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;
  toggleTheme: () => void;
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set, get) => ({
      theme: 'dark',
      
      setTheme: (theme) => {
        set({ theme });
        document.body.classList.toggle('light', theme === 'light');
      },
      
      toggleTheme: () => {
        const newTheme = get().theme === 'dark' ? 'light' : 'dark';
        set({ theme: newTheme });
        document.body.classList.toggle('light', newTheme === 'light');
      },
    }),
    {
      name: 'theme-storage',
    }
  )
);

// Store pour les données du dashboard
interface DashboardData {
  summary: {
    total_clients: number;
    total_backups: number;
    backups_ok: number;
    backups_warning: number;
    backups_alert: number;
    backups_critical: number;
    backups_failed: number;
    unresolved_alerts: number;
    health_percentage: number;
    last_update: string | null;
  } | null;
  statusOverview: any[];
  recentEvents: any[];
  alerts: any[];
  trends: any[];
  isLoading: boolean;
  error: string | null;
  fetchDashboard: () => Promise<void>;
}

export const useDashboardStore = create<DashboardData>((set) => ({
  summary: null,
  statusOverview: [],
  recentEvents: [],
  alerts: [],
  trends: [],
  isLoading: false,
  error: null,

  fetchDashboard: async () => {
    set({ isLoading: true, error: null });
    try {
      const [summaryRes, overviewRes, eventsRes, alertsRes, trendsRes] = await Promise.all([
        api.get('/dashboard/summary'),
        api.get('/dashboard/status-overview'),
        api.get('/dashboard/recent-events'),
        api.get('/dashboard/alerts'),
        api.get('/dashboard/trends'),
      ]);

      set({
        summary: summaryRes.data,
        statusOverview: overviewRes.data,
        recentEvents: eventsRes.data,
        alerts: alertsRes.data,
        trends: trendsRes.data,
        isLoading: false,
      });
    } catch (error: any) {
      set({
        error: error.response?.data?.detail || 'Erreur de chargement',
        isLoading: false,
      });
    }
  },
}));
