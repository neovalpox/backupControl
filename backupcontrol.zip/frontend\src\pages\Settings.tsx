import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  EnvelopeIcon,
  SparklesIcon,
  BellIcon,
  ShieldCheckIcon,
  Cog6ToothIcon,
  CheckCircleIcon,
  ExclamationCircleIcon,
} from '@heroicons/react/24/outline';
import { settingsApi, emailsApi } from '../api';

interface Settings {
  // Email settings
  email_provider: string;
  email_host: string;
  email_port: number;
  email_username: string;
  email_password: string;
  email_use_ssl: boolean;
  email_folder: string;
  
  // AI settings
  ai_provider: string;
  ai_api_key: string;
  ai_model: string;
  
  // Notifications
  notification_email_enabled: boolean;
  notification_email_to: string;
  notification_telegram_enabled: boolean;
  notification_telegram_token: string;
  notification_telegram_chat_id: string;
  
  // Scheduler
  scheduler_email_check_interval: number;
  scheduler_enabled: boolean;
}

export default function Settings() {
  const { t } = useTranslation();
  const [settings, setSettings] = useState<Settings>({
    email_provider: 'imap',
    email_host: '',
    email_port: 993,
    email_username: '',
    email_password: '',
    email_use_ssl: true,
    email_folder: 'INBOX',
    ai_provider: 'anthropic',
    ai_api_key: '',
    ai_model: 'claude-3-haiku-20240307',
    notification_email_enabled: false,
    notification_email_to: '',
    notification_telegram_enabled: false,
    notification_telegram_token: '',
    notification_telegram_chat_id: '',
    scheduler_email_check_interval: 60,
    scheduler_enabled: true,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testingEmail, setTestingEmail] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [activeTab, setActiveTab] = useState('email');

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const data = await settingsApi.getAll();
      // Convert array of settings to object
      const settingsObj: Record<string, any> = {};
      data.forEach((s: { key: string; value: any }) => {
        settingsObj[s.key] = s.value;
      });
      setSettings((prev) => ({ ...prev, ...settingsObj }));
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Convert settings object to array format
      const settingsArray = Object.entries(settings).map(([key, value]) => ({
        key,
        value: String(value),
      }));
      await settingsApi.updateBatch(settingsArray);
      setTestResult({ success: true, message: t('settings.saved') });
    } catch (error) {
      console.error('Error saving settings:', error);
      setTestResult({ success: false, message: t('settings.saveFailed') });
    } finally {
      setSaving(false);
      setTimeout(() => setTestResult(null), 3000);
    }
  };

  const handleTestEmail = async () => {
    setTestingEmail(true);
    setTestResult(null);
    try {
      const result = await emailsApi.testConnection();
      setTestResult({
        success: result.success,
        message: result.message || (result.success ? t('settings.emailConnected') : t('settings.emailFailed')),
      });
    } catch (error: any) {
      setTestResult({
        success: false,
        message: error.response?.data?.detail || t('settings.emailFailed'),
      });
    } finally {
      setTestingEmail(false);
    }
  };

  const tabs = [
    { id: 'email', name: t('settings.tabs.email'), icon: EnvelopeIcon },
    { id: 'ai', name: t('settings.tabs.ai'), icon: SparklesIcon },
    { id: 'notifications', name: t('settings.tabs.notifications'), icon: BellIcon },
    { id: 'scheduler', name: t('settings.tabs.scheduler'), icon: Cog6ToothIcon },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">{t('settings.title')}</h1>
        <p className="text-gray-400 mt-1">{t('settings.subtitle')}</p>
      </div>

      {/* Result notification */}
      {testResult && (
        <div className={`flex items-center p-4 rounded-lg ${
          testResult.success
            ? 'bg-green-500/10 text-green-500 border border-green-500'
            : 'bg-red-500/10 text-red-500 border border-red-500'
        }`}>
          {testResult.success ? (
            <CheckCircleIcon className="w-5 h-5 mr-2" />
          ) : (
            <ExclamationCircleIcon className="w-5 h-5 mr-2" />
          )}
          {testResult.message}
        </div>
      )}

      {/* Tabs */}
      <div className="flex space-x-1 bg-gray-800 rounded-lg p-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-colors flex-1 justify-center ${
              activeTab === tab.id
                ? 'bg-primary-600 text-white'
                : 'text-gray-400 hover:text-white hover:bg-gray-700'
            }`}
          >
            <tab.icon className="w-5 h-5 mr-2" />
            {tab.name}
          </button>
        ))}
      </div>

      {/* Settings content */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        {/* Email settings */}
        {activeTab === 'email' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-white flex items-center">
              <EnvelopeIcon className="w-5 h-5 mr-2" />
              {t('settings.email.title')}
            </h3>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {t('settings.email.provider')}
              </label>
              <select
                value={settings.email_provider}
                onChange={(e) => setSettings({ ...settings, email_provider: e.target.value })}
                className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              >
                <option value="imap">IMAP</option>
                <option value="office365">Microsoft 365</option>
                <option value="gmail">Gmail</option>
              </select>
            </div>

            {settings.email_provider === 'imap' && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      {t('settings.email.host')}
                    </label>
                    <input
                      type="text"
                      value={settings.email_host}
                      onChange={(e) => setSettings({ ...settings, email_host: e.target.value })}
                      placeholder="imap.example.com"
                      className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      {t('settings.email.port')}
                    </label>
                    <input
                      type="number"
                      value={settings.email_port}
                      onChange={(e) => setSettings({ ...settings, email_port: parseInt(e.target.value) })}
                      className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="ssl"
                    checked={settings.email_use_ssl}
                    onChange={(e) => setSettings({ ...settings, email_use_ssl: e.target.checked })}
                    className="w-4 h-4 text-primary-600 bg-gray-700 border-gray-600 rounded focus:ring-primary-500"
                  />
                  <label htmlFor="ssl" className="ml-2 text-sm text-gray-300">
                    {t('settings.email.useSSL')}
                  </label>
                </div>
              </>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {t('settings.email.username')}
                </label>
                <input
                  type="text"
                  value={settings.email_username}
                  onChange={(e) => setSettings({ ...settings, email_username: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {t('settings.email.password')}
                </label>
                <input
                  type="password"
                  value={settings.email_password}
                  onChange={(e) => setSettings({ ...settings, email_password: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {t('settings.email.folder')}
              </label>
              <input
                type="text"
                value={settings.email_folder}
                onChange={(e) => setSettings({ ...settings, email_folder: e.target.value })}
                placeholder="INBOX"
                className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>

            <button
              onClick={handleTestEmail}
              disabled={testingEmail}
              className="inline-flex items-center px-4 py-2 bg-gray-700 hover:bg-gray-600 disabled:opacity-50 text-white rounded-lg transition-colors"
            >
              <ShieldCheckIcon className={`w-5 h-5 mr-2 ${testingEmail ? 'animate-spin' : ''}`} />
              {t('settings.email.test')}
            </button>
          </div>
        )}

        {/* AI settings */}
        {activeTab === 'ai' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-white flex items-center">
              <SparklesIcon className="w-5 h-5 mr-2" />
              {t('settings.ai.title')}
            </h3>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {t('settings.ai.provider')}
              </label>
              <select
                value={settings.ai_provider}
                onChange={(e) => setSettings({ ...settings, ai_provider: e.target.value })}
                className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              >
                <option value="anthropic">Anthropic (Claude)</option>
                <option value="openai">OpenAI (GPT)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {t('settings.ai.apiKey')}
              </label>
              <input
                type="password"
                value={settings.ai_api_key}
                onChange={(e) => setSettings({ ...settings, ai_api_key: e.target.value })}
                placeholder="sk-..."
                className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
              <p className="text-gray-500 text-xs mt-1">{t('settings.ai.apiKeyHelp')}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {t('settings.ai.model')}
              </label>
              <select
                value={settings.ai_model}
                onChange={(e) => setSettings({ ...settings, ai_model: e.target.value })}
                className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              >
                {settings.ai_provider === 'anthropic' ? (
                  <>
                    <option value="claude-3-haiku-20240307">Claude 3 Haiku (rapide)</option>
                    <option value="claude-3-sonnet-20240229">Claude 3 Sonnet (équilibré)</option>
                    <option value="claude-3-opus-20240229">Claude 3 Opus (puissant)</option>
                  </>
                ) : (
                  <>
                    <option value="gpt-3.5-turbo">GPT-3.5 Turbo (rapide)</option>
                    <option value="gpt-4">GPT-4 (puissant)</option>
                    <option value="gpt-4-turbo">GPT-4 Turbo (dernier)</option>
                  </>
                )}
              </select>
            </div>
          </div>
        )}

        {/* Notifications settings */}
        {activeTab === 'notifications' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-white flex items-center">
              <BellIcon className="w-5 h-5 mr-2" />
              {t('settings.notifications.title')}
            </h3>

            {/* Email notifications */}
            <div className="p-4 bg-gray-700/50 rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <label className="text-sm font-medium text-gray-300">
                  {t('settings.notifications.email')}
                </label>
                <input
                  type="checkbox"
                  checked={settings.notification_email_enabled}
                  onChange={(e) => setSettings({ ...settings, notification_email_enabled: e.target.checked })}
                  className="w-4 h-4 text-primary-600 bg-gray-700 border-gray-600 rounded focus:ring-primary-500"
                />
              </div>
              {settings.notification_email_enabled && (
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    {t('settings.notifications.emailTo')}
                  </label>
                  <input
                    type="email"
                    value={settings.notification_email_to}
                    onChange={(e) => setSettings({ ...settings, notification_email_to: e.target.value })}
                    placeholder="admin@example.com"
                    className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              )}
            </div>

            {/* Telegram notifications */}
            <div className="p-4 bg-gray-700/50 rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <label className="text-sm font-medium text-gray-300">
                  {t('settings.notifications.telegram')}
                </label>
                <input
                  type="checkbox"
                  checked={settings.notification_telegram_enabled}
                  onChange={(e) => setSettings({ ...settings, notification_telegram_enabled: e.target.checked })}
                  className="w-4 h-4 text-primary-600 bg-gray-700 border-gray-600 rounded focus:ring-primary-500"
                />
              </div>
              {settings.notification_telegram_enabled && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">
                      {t('settings.notifications.telegramToken')}
                    </label>
                    <input
                      type="password"
                      value={settings.notification_telegram_token}
                      onChange={(e) => setSettings({ ...settings, notification_telegram_token: e.target.value })}
                      className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">
                      {t('settings.notifications.telegramChatId')}
                    </label>
                    <input
                      type="text"
                      value={settings.notification_telegram_chat_id}
                      onChange={(e) => setSettings({ ...settings, notification_telegram_chat_id: e.target.value })}
                      className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Scheduler settings */}
        {activeTab === 'scheduler' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-white flex items-center">
              <Cog6ToothIcon className="w-5 h-5 mr-2" />
              {t('settings.scheduler.title')}
            </h3>

            <div className="flex items-center justify-between p-4 bg-gray-700/50 rounded-lg">
              <div>
                <p className="text-white font-medium">{t('settings.scheduler.enabled')}</p>
                <p className="text-gray-400 text-sm">{t('settings.scheduler.enabledHelp')}</p>
              </div>
              <input
                type="checkbox"
                checked={settings.scheduler_enabled}
                onChange={(e) => setSettings({ ...settings, scheduler_enabled: e.target.checked })}
                className="w-4 h-4 text-primary-600 bg-gray-700 border-gray-600 rounded focus:ring-primary-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {t('settings.scheduler.interval')}
              </label>
              <div className="flex items-center space-x-4">
                <input
                  type="number"
                  value={settings.scheduler_email_check_interval}
                  onChange={(e) => setSettings({ ...settings, scheduler_email_check_interval: parseInt(e.target.value) })}
                  min="5"
                  max="1440"
                  className="w-32 px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
                <span className="text-gray-400">{t('settings.scheduler.minutes')}</span>
              </div>
              <p className="text-gray-500 text-xs mt-1">{t('settings.scheduler.intervalHelp')}</p>
            </div>
          </div>
        )}
      </div>

      {/* Save button */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={saving}
          className="inline-flex items-center px-6 py-3 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 text-white font-medium rounded-lg transition-colors"
        >
          {saving ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
          ) : (
            <CheckCircleIcon className="w-5 h-5 mr-2" />
          )}
          {t('settings.save')}
        </button>
      </div>
    </div>
  );
}
