import axios from 'axios';
import { useAuthStore } from './store';

const API_URL = import.meta.env.VITE_API_URL || '/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Intercepteur pour ajouter le token
api.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().token;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Intercepteur pour gérer les erreurs 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      useAuthStore.getState().logout();
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;

// Types API
export interface User {
  id: number;
  username: string;
  email: string;
  full_name?: string;
  role: 'admin' | 'technician' | 'readonly';
  is_active: boolean;
  language: string;
  theme: string;
}

export interface Client {
  id: number;
  name: string;
  contact_email?: string;
  contact_phone?: string;
  nas_identifier?: string;
  email_pattern?: string;
  sla_hours?: number;
  notes?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  backup_count?: number;
  last_backup_status?: string;
}

export interface Backup {
  id: number;
  name: string;
  client_id: number;
  client_name?: string;
  backup_type: string;
  source_path?: string;
  destination_path?: string;
  schedule?: string;
  retention_days?: number;
  is_active: boolean;
  maintenance_mode: boolean;
  maintenance_reason?: string;
  last_status?: string;
  last_run?: string;
  last_size?: number;
  last_duration?: number;
  success_count: number;
  failure_count: number;
  created_at: string;
  updated_at: string;
}

export interface BackupEvent {
  id: number;
  backup_id: number;
  status: string;
  event_date: string;
  message?: string;
  size_bytes?: number;
  duration_seconds?: number;
  source_data?: Record<string, any>;
}

export interface Alert {
  id: number;
  title: string;
  description?: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  client_id?: number;
  client_name?: string;
  backup_id?: number;
  backup_name?: string;
  acknowledged_at?: string;
  acknowledged_by?: number;
  resolved_at?: string;
  resolved_by?: number;
  resolution_notes?: string;
  created_at: string;
}

export interface Email {
  id: number;
  message_id: string;
  subject: string;
  sender: string;
  received_at: string;
  body?: string;
  body_preview: string;
  processed: boolean;
  ai_analyzed: boolean;
  extracted_status?: string;
  extracted_client?: string;
  extracted_backup?: string;
  ai_response?: Record<string, any>;
}

export interface Setting {
  id: number;
  key: string;
  value: string;
  description?: string;
}

// Auth API
export const authApi = {
  login: async (username: string, password: string) => {
    const formData = new FormData();
    formData.append('username', username);
    formData.append('password', password);
    const { data } = await api.post('/auth/login', formData, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    });
    return data;
  },
  register: async (userData: Partial<User> & { password: string }) => {
    const { data } = await api.post('/auth/register', userData);
    return data;
  },
  me: async () => {
    const { data } = await api.get('/auth/me');
    return data;
  },
};

// Dashboard API
export const dashboardApi = {
  getSummary: async () => {
    const { data } = await api.get('/dashboard/summary');
    return data;
  },
  getStatusOverview: async () => {
    const { data } = await api.get('/dashboard/status-overview');
    return data;
  },
  getRecentEvents: async (limit = 10) => {
    const { data } = await api.get('/dashboard/recent-events', { params: { limit } });
    return data;
  },
  getAlerts: async (limit = 5) => {
    const { data } = await api.get('/dashboard/alerts', { params: { limit } });
    return data;
  },
  getTrends: async (days = 30) => {
    const { data } = await api.get('/dashboard/trends', { params: { days } });
    return data;
  },
};

// Users API
export const usersApi = {
  getAll: async () => {
    const { data } = await api.get('/users');
    return data;
  },
  getOne: async (id: number) => {
    const { data } = await api.get(`/users/${id}`);
    return data;
  },
  create: async (userData: Partial<User> & { password: string }) => {
    const { data } = await api.post('/users', userData);
    return data;
  },
  update: async (id: number, userData: Partial<User>) => {
    const { data } = await api.put(`/users/${id}`, userData);
    return data;
  },
  delete: async (id: number) => {
    const { data } = await api.delete(`/users/${id}`);
    return data;
  },
};

// Clients API
export const clientsApi = {
  getAll: async (params?: { is_active?: boolean }) => {
    const { data } = await api.get('/clients', { params });
    return data;
  },
  getOne: async (id: number) => {
    const { data } = await api.get(`/clients/${id}`);
    return data;
  },
  create: async (clientData: Partial<Client>) => {
    const { data } = await api.post('/clients', clientData);
    return data;
  },
  update: async (id: number, clientData: Partial<Client>) => {
    const { data } = await api.put(`/clients/${id}`, clientData);
    return data;
  },
  delete: async (id: number) => {
    const { data } = await api.delete(`/clients/${id}`);
    return data;
  },
  getStats: async (id: number) => {
    const { data } = await api.get(`/clients/${id}/stats`);
    return data;
  },
};

// Backups API
export const backupsApi = {
  getAll: async (params?: { client_id?: number; status?: string }) => {
    const { data } = await api.get('/backups', { params });
    return data;
  },
  getOne: async (id: number) => {
    const { data } = await api.get(`/backups/${id}`);
    return data;
  },
  create: async (backupData: Partial<Backup>) => {
    const { data } = await api.post('/backups', backupData);
    return data;
  },
  update: async (id: number, backupData: Partial<Backup>) => {
    const { data } = await api.put(`/backups/${id}`, backupData);
    return data;
  },
  delete: async (id: number) => {
    const { data } = await api.delete(`/backups/${id}`);
    return data;
  },
  setMaintenance: async (id: number, enable: boolean, reason?: string) => {
    const { data } = await api.post(`/backups/${id}/maintenance`, { enable, reason });
    return data;
  },
  getEvents: async (id: number, params?: { limit?: number }) => {
    const { data } = await api.get(`/backups/${id}/events`, { params });
    return data;
  },
};

// Alerts API
export const alertsApi = {
  getAll: async (params?: { active?: boolean; acknowledged?: boolean; resolved?: boolean; severity?: string }) => {
    const { data } = await api.get('/alerts', { params });
    return data;
  },
  getActive: async () => {
    const { data } = await api.get('/alerts', { params: { active: true } });
    return data;
  },
  acknowledge: async (id: number) => {
    const { data } = await api.post(`/alerts/${id}/acknowledge`);
    return data;
  },
  resolve: async (id: number, notes?: string) => {
    const { data } = await api.post(`/alerts/${id}/resolve`, { notes });
    return data;
  },
};

// Emails API
export const emailsApi = {
  getAll: async (params?: { backup_only?: boolean; limit?: number }) => {
    const { data } = await api.get('/emails', { params });
    return data;
  },
  getById: async (id: number) => {
    const { data } = await api.get(`/emails/${id}`);
    return data;
  },
  testConnection: async () => {
    const { data } = await api.get('/emails/test-connection');
    return data;
  },
  fetch: async (limit?: number) => {
    const { data } = await api.post('/emails/fetch', { limit });
    return data;
  },
  fetchNew: async () => {
    const { data } = await api.post('/emails/fetch');
    return data;
  },
  analyze: async () => {
    const { data } = await api.post('/emails/analyze');
    return data;
  },
  analyzeAll: async () => {
    const { data } = await api.post('/emails/analyze');
    return data;
  },
};

// Settings API
export const settingsApi = {
  getAll: async () => {
    const { data } = await api.get('/settings');
    return data;
  },
  get: async (key: string) => {
    const { data } = await api.get(`/settings/${key}`);
    return data;
  },
  update: async (key: string, value: string) => {
    const { data } = await api.put(`/settings/${key}`, { value });
    return data;
  },
  updateBatch: async (settings: Record<string, string>) => {
    const { data } = await api.put('/settings/batch', settings);
    return data;
  },
};

// AI Suggestions API
export const aiApi = {
  getSuggestions: async (params?: { dismissed?: boolean; implemented?: boolean }) => {
    const { data } = await api.get('/ai-suggestions', { params });
    return data;
  },
  dismiss: async (id: number) => {
    const { data } = await api.post(`/ai-suggestions/${id}/dismiss`);
    return data;
  },
  implement: async (id: number) => {
    const { data } = await api.post(`/ai-suggestions/${id}/implement`);
    return data;
  },
  generate: async () => {
    const { data } = await api.post('/ai-suggestions/generate');
    return data;
  },
};
