"""
Routes de gestion des e-mails
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

from app.core.database import get_db
from app.core.security import get_current_user, get_current_tech_user
from app.models.user import User
from app.models.email import Email
from app.services.email_service import get_email_provider
from app.services.scheduler import scheduler_service

router = APIRouter()


class EmailResponse(BaseModel):
    id: int
    message_id: str
    subject: str
    sender: str
    received_at: datetime
    is_backup_notification: bool
    detected_type: Optional[str]
    detected_status: Optional[str]
    detected_nas: Optional[str]
    ai_confidence: Optional[int]
    is_processed: bool
    
    class Config:
        from_attributes = True


class EmailDetailResponse(EmailResponse):
    body_text: Optional[str]
    ai_extracted_data: Optional[dict]


class EmailTestResult(BaseModel):
    success: bool
    message: str
    server: Optional[str] = None
    email: Optional[str] = None
    total_emails: Optional[int] = None


@router.get("/", response_model=List[EmailResponse])
async def list_emails(
    backup_only: bool = False,
    limit: int = 100,
    offset: int = 0,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Liste les e-mails analysés"""
    query = select(Email)
    
    if backup_only:
        query = query.where(Email.is_backup_notification == True)
    
    query = query.order_by(Email.received_at.desc()).offset(offset).limit(limit)
    
    result = await db.execute(query)
    emails = result.scalars().all()
    
    return [
        EmailResponse(
            id=e.id,
            message_id=e.message_id,
            subject=e.subject,
            sender=e.sender,
            received_at=e.received_at,
            is_backup_notification=e.is_backup_notification,
            detected_type=e.detected_type,
            detected_status=e.detected_status,
            detected_nas=e.detected_nas,
            ai_confidence=e.ai_confidence,
            is_processed=e.is_processed
        )
        for e in emails
    ]


@router.get("/{email_id}", response_model=EmailDetailResponse)
async def get_email(
    email_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Récupère le détail d'un e-mail"""
    result = await db.execute(
        select(Email).where(Email.id == email_id)
    )
    email = result.scalar_one_or_none()
    
    if not email:
        raise HTTPException(status_code=404, detail="E-mail non trouvé")
    
    return EmailDetailResponse(
        id=email.id,
        message_id=email.message_id,
        subject=email.subject,
        sender=email.sender,
        received_at=email.received_at,
        is_backup_notification=email.is_backup_notification,
        detected_type=email.detected_type,
        detected_status=email.detected_status,
        detected_nas=email.detected_nas,
        ai_confidence=email.ai_confidence,
        is_processed=email.is_processed,
        body_text=email.body_text,
        ai_extracted_data=email.ai_extracted_data
    )


@router.post("/test-connection", response_model=EmailTestResult)
async def test_email_connection(
    current_user: User = Depends(get_current_tech_user)
):
    """Teste la connexion au serveur e-mail"""
    try:
        provider = get_email_provider()
        result = await provider.test_connection()
        return EmailTestResult(**result)
    except Exception as e:
        return EmailTestResult(
            success=False,
            message=str(e)
        )


@router.post("/fetch")
async def fetch_emails(
    limit: int = 100,
    current_user: User = Depends(get_current_tech_user)
):
    """Déclenche manuellement la récupération des e-mails"""
    try:
        provider = get_email_provider()
        await provider.connect()
        emails = await provider.fetch_emails(limit=limit)
        await provider.disconnect()
        
        return {
            "success": True,
            "fetched_count": len(emails),
            "message": f"{len(emails)} e-mails récupérés"
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Erreur lors de la récupération: {str(e)}"
        )


@router.post("/analyze")
async def trigger_analysis(
    current_user: User = Depends(get_current_tech_user)
):
    """Déclenche manuellement l'analyse complète des e-mails"""
    try:
        await scheduler_service.run_manual_analysis()
        return {
            "success": True,
            "message": "Analyse lancée avec succès"
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Erreur lors de l'analyse: {str(e)}"
        )


@router.get("/stats/summary")
async def get_email_stats(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Statistiques sur les e-mails analysés"""
    from sqlalchemy import func
    
    # Total e-mails
    result = await db.execute(select(func.count(Email.id)))
    total = result.scalar()
    
    # E-mails de backup
    result = await db.execute(
        select(func.count(Email.id)).where(Email.is_backup_notification == True)
    )
    backup_count = result.scalar()
    
    # Par statut détecté
    result = await db.execute(
        select(Email.detected_status, func.count(Email.id))
        .where(Email.is_backup_notification == True)
        .group_by(Email.detected_status)
    )
    by_status = {row[0] or "unknown": row[1] for row in result.all()}
    
    # Par type de sauvegarde
    result = await db.execute(
        select(Email.detected_type, func.count(Email.id))
        .where(Email.is_backup_notification == True)
        .group_by(Email.detected_type)
    )
    by_type = {row[0] or "unknown": row[1] for row in result.all()}
    
    return {
        "total_emails": total,
        "backup_notifications": backup_count,
        "other_emails": total - backup_count,
        "by_status": by_status,
        "by_type": by_type
    }
